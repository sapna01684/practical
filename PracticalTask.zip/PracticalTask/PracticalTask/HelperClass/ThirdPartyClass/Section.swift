

import Foundation
import EVReflection

struct Section {
    var title: String!
    var listData : [FollowersDataModel]
    var expanded: Bool!
    
    init(title: String, listData: [FollowersDataModel], expanded: Bool) {
        self.title = title
        self.listData = listData
        self.expanded = expanded
    }
}
