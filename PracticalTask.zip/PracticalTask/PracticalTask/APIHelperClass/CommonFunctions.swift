

import Foundation
import SVProgressHUD
import AVKit

let APPDELEGATE = UIApplication.shared.delegate as! AppDelegate

let API_BASE_URL = "http://api.gobeintheworld.org/"

/************************ Check network connection ************************/

func checkInternet(showToast : Bool = false) -> Bool {
    
    let status = DJReachability().connectionStatus()
    switch status {
    case .unknown, .offline:
        if showToast {
           simpleAlert("offline")
        }
        return false
    case .online(.wwan), .online(.wiFi):
        return true
    }
}


/************************ Show / Hide Hud ************************/

func showHud() {
    DispatchQueue.main.async {
        SVProgressHUD.setDefaultMaskType(SVProgressHUDMaskType.black)
        SVProgressHUD.setForegroundColor(UIColor.blue)
        SVProgressHUD.show()
    }
}

func showHud(progress : Float? = nil, status : String) {
    DispatchQueue.main.async {
        // change UI as theme changes
        if isSystemDarkMode  == false {
            SVProgressHUD.setDefaultMaskType(SVProgressHUDMaskType.black)
        }
        else {
            SVProgressHUD.setDefaultMaskType(SVProgressHUDMaskType.clear)
        }
        
        if progress != nil {
            SVProgressHUD.showProgress(progress!, status: status)
        }
        else {
            SVProgressHUD.show(withStatus: status)
        }
    }
}

func hideHud() {
    DispatchQueue.main.async {
        SVProgressHUD.dismiss()
    }
}

// SET APP THEME
var isSystemDarkMode: Bool = false {
    didSet {
        NotificationCenter.default.post(name: .ThemeDidChangeNotification, object: nil)
        SVProgressHUD.setDefaultStyle( isSystemDarkMode ? .dark : .light)
    }
}


/************************ Color ************************/
func hexStringToUIColor (hex:String) -> UIColor {
    var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
    var rgbValue:UInt32 = 0
    
    Scanner(string: cString).scanHexInt32(&rgbValue)
    if (cString.hasPrefix("#")) {
        cString.remove(at: cString.startIndex)
    }
    if ((cString.count) != 6) {
        return UIColor.gray
    }
    return UIColor(
        red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
        green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
        blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
        alpha: CGFloat(1.0)
    )
}


func setImageInContainerRatio(screenName:String,X:CGFloat,Y:CGFloat,proportion:CGFloat,innerPadding:CGFloat,isFullWidth:Bool) -> CGSize {
    let imgWidth : CGFloat?
    if isFullWidth {
        imgWidth = ((SCREEN_WIDTH)*proportion)-innerPadding
    } else {
        imgWidth = ((SCREEN_WIDTH - OUTER_PADDING) * proportion)-innerPadding
    }
    
    let imgHeight = imgWidth!*Y/X
    var size : CGSize?
    size = CGSize(width: imgWidth!, height: imgHeight)
    //  print("---------------------------------")
    //   print("Screen-",screenName)
    //   print("MainWidth-",SCREEN_WIDTH)
    //  print("ImageWidth-",imgWidth ?? "")
    //  print("ImageHeight-",imgHeight)
    //  print("---------------------------------")
    return size!
}

// Given screen width
var SCREEN_WIDTH: CGFloat {
    get {
        return UIScreen.main.bounds.size.width
    }
}

// Given screen height
var SCREEN_HEIGHT: CGFloat {
    get {
        return UIScreen.main.bounds.size.height
    }
}

var OUTER_PADDING: CGFloat {
    return 32.0
}


extension UIView {
    
    func gradient(colorTop : UIColor, colorBottom : UIColor) {
        let gradient: CAGradientLayer = CAGradientLayer()
        gradient.colors = [colorTop.cgColor, colorBottom.cgColor]
        gradient.locations = [0.0 , 0.5]
        //        gradient.startPoint = CGPoint(x: 0.0, y: 0.0)
        //        gradient.endPoint = CGPoint(x: 1.0, y: 1.0)
        gradient.frame = CGRect(x: 0.0, y: 0.0, width: self.frame.size.width, height: self.frame.size.height)
        self.layer.insertSublayer(gradient, at: 0)
    }
    
}

// Userdefault methods
func setUserDefault(ObjectToSave : AnyObject?  , KeyToSave : String) {
    let defaults = UserDefaults.standard
    if (ObjectToSave != nil) {
        defaults.set(ObjectToSave!, forKey: KeyToSave)
    }
    UserDefaults.standard.synchronize()
}

func removeUserDefault(KeyObj : String) {
    let defaults = UserDefaults.standard
    defaults.removeObject(forKey: KeyObj)
    UserDefaults.standard.synchronize()
}

func isKeyPresentInUserDefaults(key: String) -> Bool {
    return UserDefaults.standard.object(forKey: key) != nil
}

// Check network connection lost error

func checkErrorTypeNetworkLost(error:Error) -> Bool {
    if  (error as NSError).code == -1005 {
        return true
    }
    if  (error as NSError).code == -1001 {
        return true
    }
    return false
}



/***************** Show Alert Controller ******************/

func simpleAlert(_ message:String?)  {
    let alertController = UIAlertController(title: "Practical", message: message, preferredStyle: .alert)
    alertController.addAction(UIAlertAction(title: "Ok", style: .cancel, handler: nil))
    APPDELEGATE.window?.rootViewController?.present(alertController, animated: true, completion: nil)
}

extension Notification.Name {
    static let ThemeDidChangeNotification = Notification.Name("themeDidChangeNotfication")
    static let likedOrDownloadedAudio = Notification.Name("likedOrDownloadedAudio")
    static let refreshLikedList = Notification.Name("refreshLikedList")
}

extension String {
    var trim : String {
        return self.trimmingCharacters(in: .whitespacesAndNewlines)
    }
}
