

import Foundation
import CryptoKit
import Alamofire
import EVReflection


class APIManager {
    
    static let shared = APIManager()
    
    var apiRequest : DataRequest?
    
    func callAPI<M : EVObject>(router : URLRequestConvertible, displayHud : Bool = true, showToast : Bool = true, response : @escaping (M) -> Void) {
        
        if checkInternet() == false {
            simpleAlert("please check  internet connection")
            response(M())
            return
        }
        
        if displayHud {
            showHud()
        }
        
        self.apiRequest = Alamofire.request(router).responseObject { (responseObj : DataResponse<M>) in
            
            hideHud()
            
            if let error = responseObj.result.error {
                if checkErrorTypeNetworkLost(error: error) {
                    self.callAPI(router: router, response: response)
                }
            }
            
            self.handleError(data: responseObj, showToast: showToast, response: { (success) in
                if success {
                    if let value = responseObj.result.value {
                        response(value)
                        let dict = value.toDictionary()
                        if (dict["status"] as? Int) != 200 {
                            
                            if (dict["status"] as? Int) == 403 {
                                
                            } else if let message = dict["msg"] as? String, message.trim.count > 0 {
                                if showToast {
                                    simpleAlert(message)
                                    
                                }
                            }
                        }
                    }
                }
            })
        }
        .responseString { (resp) in
            print(resp)
        }
       
    }
    
    func handleError<D : EVObject>(data : DataResponse<D>, showToast : Bool = true, response : @escaping (Bool) -> Void) {
        
        guard let dict = data.result.value?.toDictionary() else {
            
            return
        }
        
        guard let message = dict.value(forKey: "msg") as? String else {
            
            return
        }
        
        switch data.response?.statusCode ?? 0 {
        case 200...299:
            response(true)
        case 401:
            
            response(false)
            if showToast && message.trim.count > 0 {
                
                simpleAlert(message)
                
            }
        default:
            response(false)
            if showToast && message.trim.count > 0 { simpleAlert(message)
                
            }
        }
    }
    
}
