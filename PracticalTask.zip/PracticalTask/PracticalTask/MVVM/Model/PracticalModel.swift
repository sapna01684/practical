

import Foundation
import EVReflection

class PracticalModel: EVObject {
    
    var Followers = [FollowersDataModel]()
    var Friends = [FollowersDataModel]()
    var YourLikes = [FollowersDataModel]()
    var YourTips = [FollowersDataModel]()
    var YourList = [FollowersDataModel]()
    var ListYouLike = [FollowersDataModel]()
    var FriendsLists = [FollowersDataModel]()
    var PublicList = [FollowersDataModel]()
    var status : Int?
    var msg: String?
    var FriendsFollowers: String?
}

class FollowersDataModel: EVObject {
    
    var LikeStatus = ""
    var FriendStatus = ""
    var FollowerStatus = ""
    var TipID = ""
    var AuthorID = ""
    var AuthorName = ""
    var Title = ""
    var Description = ""
    var Address = ""
    var Img = ""
    var Country = ""
    var Postcode = ""
    var TipType = ""
    var Latitude = ""
    var Longitude = ""
    var Category = ""
    var PodSetting = ""
    var PostDate = ""
    var LikeList = ""
    var isExpanded : Bool = false
    
}

