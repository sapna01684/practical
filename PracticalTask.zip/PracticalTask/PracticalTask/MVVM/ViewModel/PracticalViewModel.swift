

import Foundation

class PracticalViewModel {
    
    var arrFlowers = [FollowersDataModel]()
    var arrFriends = [FollowersDataModel]()
    var rarrYourLikes = [FollowersDataModel]()
    var arrYourTips = [FollowersDataModel]()
    var arrYourList = [FollowersDataModel]()
    var arrListYouLike = [FollowersDataModel]()
    var arrFriendsLists = [FollowersDataModel]()
    var arrPublicList = [FollowersDataModel]()
    
    func callListAPI(parameter:[String:Any], completion: @escaping (Bool) -> Void) {
        
        APIManager.shared.callAPI(router:APIRouter.alllist(parameter)) { [weak self] (response : PracticalModel?) in
            
            if (response?.Followers.count)! > 0 {
                
                self?.arrFlowers = response?.Followers ?? []
                self?.arrFriends = response?.Friends ?? []
                self?.rarrYourLikes = response?.YourLikes ?? []
                self?.arrYourTips = response?.YourTips ?? []
                self?.arrYourList = response?.YourList ?? []
                self?.arrListYouLike = response?.ListYouLike ?? []
                self?.arrFriendsLists = response?.FriendsLists ?? []
                self?.arrPublicList = response?.PublicList ?? []
                
                completion(true)
            } else {
                completion(false)
            }
        }
    }
    
}

