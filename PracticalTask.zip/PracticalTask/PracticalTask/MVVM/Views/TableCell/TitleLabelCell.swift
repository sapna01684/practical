

import UIKit

class TitleLabelCell: UITableViewCell {
    
    // MARK:- OUTLET
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var btnViewAll: UIButton!
    
    // MARK:- VARIABLES
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
       
    }
}
