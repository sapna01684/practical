

import UIKit
import SDWebImage

class ListCell: UITableViewCell {
    
    // MARK:- OUTLET
    
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblSubTitle: UILabel!
    @IBOutlet weak var lblDesignation: UILabel!
    
    // MARK:- VARIABLES
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
    
    func configureCell(data : FollowersDataModel) {
        self.lblTitle.text = data.Title
        self.lblSubTitle.text = data.Address
        self.lblDesignation.text = data.Description
        
        if let strUrl = data.Img.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed), let imgUrl = URL(string: strUrl) {
            img.sd_setImage(with: imgUrl, completed: nil)
        }
    }
}
