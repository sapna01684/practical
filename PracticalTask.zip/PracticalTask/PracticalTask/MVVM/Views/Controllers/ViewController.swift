
import UIKit

class ViewController: UIViewController, ExpandableHeaderViewDelegate {
    
    //MARK:- UIOutlet
    @IBOutlet weak var tableView: UITableView!
    
    //MARK:- Variables
    
    var arrFlowers : [FollowersDataModel] = []
    var arrFriends : [FollowersDataModel] = []
    var rarrYourLikes : [FollowersDataModel] = []
    var arrYourTips : [FollowersDataModel] = []
    var arrYourList : [FollowersDataModel] = []
    var arrListYouLike : [FollowersDataModel] = []
    var arrFriendsLists : [FollowersDataModel] = []
    var arrPublicList : [FollowersDataModel] = []
    
    var sections = [Section]()

    //MARK:- View Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        apiCall()
    }
   
    //MARK:- Functions
     func setupUI() {
        
         tableView.register(UINib(nibName: "ListCell", bundle: nil), forCellReuseIdentifier: "ListCell")
         tableView.register(UINib(nibName: "TitleLabelCell", bundle: nil), forCellReuseIdentifier: "TitleLabelCell")
         tableView.delegate = self
         tableView.dataSource = self
    }
    
     func setupData() {
         
             sections = [
                Section(title: "Followers", listData: arrFlowers, expanded: false),
                Section(title: "Friends",
                        listData: arrFriends,
                        expanded: false),
                Section(title: "YourLikes",
                        listData: rarrYourLikes,
                        expanded: false),
                Section(title: "YourTips",
                        listData: arrYourTips,
                        expanded: false),
                Section(title: "YourList",
                        listData: arrYourList,
                        expanded: false),
                Section(title: " ListYouLike",
                        listData: arrListYouLike,
                        expanded: false),
                Section(title: " FriendsLists",
                        listData: arrFriendsLists,
                        expanded: false),
                Section(title: " PublicList",
                        listData: arrPublicList,
                        expanded: false)
                
             ]
    }
    
    func apiCall() {
        
        let vm = PracticalViewModel()
        
        let parameters = ["UserID":"363"]
        
        vm.callListAPI(parameter: parameters)
        { success in
            if success {
                
                self.arrFlowers = vm.arrFlowers
                self.arrFriends = vm.arrFriends
                self.rarrYourLikes = vm.rarrYourLikes
                self.arrYourTips = vm.arrYourTips
                self.arrYourList = vm.arrYourList
                self.arrListYouLike = vm.arrListYouLike
                self.arrFriendsLists = vm.arrFriendsLists
                self.arrPublicList = vm.arrPublicList
            }
            self.setupData()
            self.tableView.reloadData()
            
        }
    }
    
}

//MARK: - UITableView Methods

extension ViewController : UITableViewDelegate, UITableViewDataSource {

    func numberOfSections(in tableView: UITableView) -> Int {
        
        return sections.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return sections[section].listData.count
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 44
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if (sections[indexPath.section].expanded) {
            return 200
        } else {
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 2
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
       
        let header = ExpandableHeaderView()
        header.customInit(title: sections[section].title, section: section, delegate: self)
        return header
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:ListCell = tableView.dequeueReusableCell(withIdentifier: "ListCell")! as! ListCell
        
        cell.configureCell(data: sections[indexPath.section].listData[indexPath.row])
        
        return cell
    }
    
    func toggleSection(header: ExpandableHeaderView, section: Int) {
        
        sections[section].expanded = !sections[section].expanded
        
        
        tableView.beginUpdates()
        for i in 0 ..< sections[section].listData.count {
            tableView.reloadRows(at: [IndexPath(row: i, section: section)], with: .none)
        }
        tableView.endUpdates()
    
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }

}
